package com.example.lab3.databaseProject

import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.lab3.R
import com.example.lab3.databaseProject.utils.PreferenceUtils
import com.example.lab3.db.AppDatabase
import com.example.lab3.db.entities.Plan
import kotlinx.android.synthetic.main.activity_add_todo_item.*

class AddTodoItemActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener, View.OnClickListener {

    var priorityLevels = arrayOf("low", "medium", "high")
    lateinit var priorityLevel : String
    lateinit var currentUser : String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_todo_item)

        initUI()
    }

    private fun initUI() {
        save_button.setOnClickListener(this)
        backBtn.setOnClickListener(this)

        plan_priority.onItemSelectedListener = this
        val array_adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, priorityLevels)
        array_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        plan_priority!!.adapter = array_adapter
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        //textView_msg!!.text = "Selected : "+languages[position]
        priorityLevel = priorityLevels[position]
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        Toast.makeText(this, getString(R.string.select_priority_level_error), Toast.LENGTH_LONG).show()
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.save_button -> {
                if(!plan_title.text.isEmpty() && !plan_content.text.isEmpty()){
                    currentUser = PreferenceUtils.getCurrentUser(this)
                    AsyncTask.execute {
                        AppDatabase.getDatabase(applicationContext)
                            ?.getPlanDao()
                            ?.insertPlan(
                                Plan(
                                    email = currentUser,
                                    title = plan_title.text.toString(),
                                    content = plan_content.text.toString(),
                                    priority = priorityLevel
                                )
                            )
                    }
                }
                else{
                    Toast.makeText(this, R.string.fill_all_fields_error, Toast.LENGTH_LONG).show()
                }
            }

            R.id.backBtn -> {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }

    }
}
