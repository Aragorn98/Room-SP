package com.example.lab3.db.dao

import android.arch.persistence.room.*
import com.example.lab3.db.entities.Plan

@Dao
interface PlanDao {
    @Insert
    fun insertPlan(plan: Plan)

    @Update
    fun updatePlan(plan: Plan)

    @Delete
    fun deletePlan(plan: Plan)

    @Query("SELECT * FROM plans WHERE email == :email")
    fun getPlansByEmail(email : String): List<Plan>
}