package com.example.lab3.databaseProject

import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.lab3.R
import com.example.lab3.databaseProject.utils.PreferenceUtils
import com.example.lab3.db.AppDatabase
import com.example.lab3.db.entities.User
import kotlinx.android.synthetic.main.activity_registration.*

class RegistrationActivity : AppCompatActivity(), View.OnClickListener {

    var savedPassword : String? = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        initUI()
    }

    private fun initUI() {
        sign_up_button.setOnClickListener(this)
        go_to_login_button.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.sign_up_button -> {
                if(!reg_name.text.isEmpty() && !reg_surname.text.isEmpty() && !reg_email.text.isEmpty()
                    && !reg_password.text.isEmpty()){
                    AsyncTask.execute {
                            savedPassword = AppDatabase.getDatabase(applicationContext)
                            ?.getUserDao()
                            ?.getUserPassword(reg_email.text.toString())

                        runOnUiThread {
                            if(savedPassword != null){
                                Toast.makeText(this, getString(R.string.user_already_exists_error), Toast.LENGTH_LONG).show()
                            }
                            else{
                                AsyncTask.execute {
                                    AppDatabase.getDatabase(applicationContext)
                                        ?.getUserDao()
                                        ?.insertUser(
                                            User(
                                                name = reg_name.text.toString(),
                                                surname = reg_surname.text.toString(),
                                                email = reg_email.text.toString(),
                                                password = reg_password.text.toString()
                                            )
                                        )}
                                PreferenceUtils.saveLoggedIn(this, true)
                                PreferenceUtils.setCurrentUser(this, reg_email.text.toString())
                                startActivity(Intent(this, MainActivity::class.java))
                                finish()
                            }
                        }
                    }


                }
                else{
                    Toast.makeText(this, getString(R.string.fill_all_fields_error), Toast.LENGTH_LONG).show()
                }
            }

            R.id.go_to_login_button -> {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }
    }
}
