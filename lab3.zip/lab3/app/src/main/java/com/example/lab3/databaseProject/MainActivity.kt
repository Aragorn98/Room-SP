package com.example.lab3.databaseProject

import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.example.lab3.R
import com.example.lab3.databaseProject.adapter.OnDeleteClickedListener
import com.example.lab3.databaseProject.adapter.OnUpdateClickedListener
import com.example.lab3.databaseProject.adapter.PlansAdapter
import com.example.lab3.databaseProject.utils.PreferenceUtils
import com.example.lab3.db.AppDatabase
import com.example.lab3.db.entities.Plan
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), View.OnClickListener, OnUpdateClickedListener, OnDeleteClickedListener {

    lateinit var currentUser : String

    override fun onUpdateClicked(plan: Plan) {
        plan.content = "Default Content"
        plan.title = "Default Title"
        AsyncTask.execute {
            AppDatabase.getDatabase(applicationContext)
                ?.getPlanDao()
                ?.updatePlan(plan)
        }
    }

    override fun onDeleteClicked(plan: Plan) {
        AsyncTask.execute {
            AppDatabase.getDatabase(applicationContext)
                ?.getPlanDao()
                ?.deletePlan(plan)
        }
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initUI()
    }

    private fun initUI() {
        if(!PreferenceUtils.isLoggedIn(this)){
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
        add_item.setOnClickListener(this)
        logout_button.setOnClickListener(this)

        plans_list.layoutManager = LinearLayoutManager(this)
        currentUser = PreferenceUtils.getCurrentUser(this)

        AsyncTask.execute {

            val plans = AppDatabase.getDatabase(applicationContext)
                ?.getPlanDao()
                ?.getPlansByEmail(currentUser)


            runOnUiThread {
                val adapter = PlansAdapter(plans!!, this@MainActivity,
                    this@MainActivity)

                plans_list.adapter = adapter
            }
        }
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.add_item -> {
                startActivity(Intent(this, AddTodoItemActivity::class.java))
                finish()
            }
            R.id.logout_button -> {
                PreferenceUtils.saveLoggedIn(this, false)
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }

    }
}

