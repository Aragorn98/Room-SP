package com.example.lab3.databaseProject.utils

import android.content.Context
import android.preference.PreferenceManager

object PreferenceUtils{
    private const val PREF_IS_LOGGED_IN = "is_logged_in"
    private const val PREF_CURRENT_USER = "current_user"

    private fun getPreferences(context: Context)
            = PreferenceManager.getDefaultSharedPreferences(context)

    fun saveLoggedIn(context: Context, loggedIn: Boolean) {
        getPreferences(context).edit().putBoolean(PREF_IS_LOGGED_IN, loggedIn).apply()
    }

    fun isLoggedIn(context: Context) =
        getPreferences(context).getBoolean(PREF_IS_LOGGED_IN, false)

    fun setCurrentUser(context: Context, email: String) {
        getPreferences(context).edit().putString(PREF_CURRENT_USER, email).apply()
    }

    fun getCurrentUser(context: Context) =
            getPreferences(context).getString(PREF_CURRENT_USER, "")
}