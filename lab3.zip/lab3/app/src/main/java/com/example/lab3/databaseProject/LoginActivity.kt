package com.example.lab3.databaseProject

import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.lab3.R
import com.example.lab3.databaseProject.utils.PreferenceUtils
import com.example.lab3.db.AppDatabase
import com.example.lab3.db.entities.User
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity(), View.OnClickListener {

    var savedPassword : String? = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        initUI()
    }

    private fun initUI() {
        login_button.setOnClickListener(this)
        go_to_Sign_up.setOnClickListener(this)



    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.login_button -> {
                if(!login_email.text.isEmpty() && !login_password.text.isEmpty()){
                    AsyncTask.execute {
                            savedPassword = AppDatabase.getDatabase(applicationContext)
                            ?.getUserDao()
                            ?.getUserPassword(login_email.text.toString())

                        runOnUiThread {
                            if(savedPassword == null){
                                Toast.makeText(this, getString(R.string.not_registered_error), Toast.LENGTH_LONG).show()
                            }
                            else if(login_password.text.toString() != savedPassword){
                                Toast.makeText(this, getString(R.string.wrong_password_error), Toast.LENGTH_LONG).show()
                            }
                            else{
                                PreferenceUtils.saveLoggedIn(this, true)
                                PreferenceUtils.setCurrentUser(this, login_email.text.toString())
                                startActivity(Intent(this, MainActivity::class.java))
                                finish()
                            }
                        }
                    }

                }
                else{
                    Toast.makeText(this, R.string.fill_all_fields_error, Toast.LENGTH_LONG).show()
                }
            }

            R.id.go_to_Sign_up -> {
                startActivity(Intent(this, RegistrationActivity::class.java))
                finish()
            }
        }
    }

}
