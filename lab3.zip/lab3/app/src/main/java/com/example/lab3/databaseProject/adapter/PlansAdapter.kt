package com.example.lab3.databaseProject.adapter

import android.graphics.Color
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.lab3.R
import com.example.lab3.db.entities.Plan
import kotlinx.android.synthetic.main.layout_item_plan.view.*

class PlansAdapter(private val plans: List<Plan>,
                   private val onUpdateClickedListener: OnUpdateClickedListener,
                   private val onDeleteClickedListener: OnDeleteClickedListener)
    : RecyclerView.Adapter<PlansAdapter.PlanViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)
            = PlanViewHolder(
        LayoutInflater.from(parent.context)
        .inflate(R.layout.layout_item_plan, parent, false))

    override fun onBindViewHolder(holder: PlanViewHolder, position: Int) {
        holder.bindPlan(plans[position])
        holder.updateBtn.setOnClickListener{
            onUpdateClickedListener.onUpdateClicked(plans[position])
            notifyDataSetChanged()
        }
        holder.deleteBtn.setOnClickListener{
            onDeleteClickedListener.onDeleteClicked(plans[position])
            notifyDataSetChanged()
        }
    }

    override fun getItemCount() = plans.size

    inner class PlanViewHolder(view: View): RecyclerView.ViewHolder(view) {

        fun bindPlan(plan: Plan) {
            itemView.title.text = plan.title
            itemView.content.text = plan.content
            itemView.priority.text = plan.priority
            var color = when(plan.priority){
                "low" -> Color.WHITE
                "medium" -> Color.YELLOW
                "high" ->  Color.RED
                else -> Color.BLACK
            }
            itemView.setBackgroundColor(color)
        }
        val updateBtn =view.updateBtn
        val deleteBtn =view.deleteBtn
    }
}


interface OnUpdateClickedListener {
    fun onUpdateClicked(plan: Plan)
}
interface OnDeleteClickedListener {
    fun onDeleteClicked(plan: Plan)
}